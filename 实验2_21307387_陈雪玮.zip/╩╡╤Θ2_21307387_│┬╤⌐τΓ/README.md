复现：mbr.asm

思考题：

14.cs.asm

16.

1. move.asm

2. num.asm

3. keyb.asm

17.assignment/student.asm


